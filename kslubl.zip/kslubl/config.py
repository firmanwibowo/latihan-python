__version__ = '0.0.1'

DEBUG = True
TESTING = False

SESSION_TYPE = 'memcache'

SQLALCHEMY_DATABASE_URI = 'sqlite:///ksl.db'
SQLALCHEMY_TRACK_MODIFICATIONS = False
